# 🛡 Smart Unattended Object Detection

> Real-time surveillance system that detects unattended bags and luggage using **YOLOv8** + **DeepSORT**, with owner-linking, multi-level alerting, a Streamlit dashboard, and structured logging.

![Python](https://img.shields.io/badge/Python-3.10%2B-blue?logo=python)
![YOLOv8](https://img.shields.io/badge/YOLOv8-Ultralytics-purple)
![Streamlit](https://img.shields.io/badge/Streamlit-1.32%2B-red?logo=streamlit)
![License](https://img.shields.io/badge/License-MIT-green)

---

## How it works

```
Webcam / Video
      │
      ▼
  YOLOv8 Detection ──► person, backpack, handbag, suitcase
      │
      ▼
  DeepSORT Tracking ──► stable IDs across frames
      │
      ▼
  Owner-linking ──► nearest person → bag within N pixels
      │
      ▼
  Alert engine
    ├─ owner close      → SAFE  ✅
    ├─ away > 5 s       → WARNING  ⚠️  (alarm at 50 % volume)
    └─ away > 10 s      → CRITICAL 🚨  (alarm + screenshot)
      │
      ▼
  Streamlit Dashboard ──► live feed, metrics, event log
```

---

## Features

| Feature | Details |
|---|---|
| **Detection** | YOLOv8n/s/m/l — swap model in `config.yaml` |
| **Tracking** | DeepSORT with MobileNet appearance embedder |
| **Owner-linking** | Nearest-person assignment at first detection |
| **Alert levels** | Safe → Warning → Critical with configurable timers |
| **Alarm** | Non-blocking audio via pygame |
| **Screenshots** | Auto-captured on CRITICAL, manual via dashboard |
| **Dashboard** | Live feed, metric cards, object table, event log, perf panel |
| **Configuration** | All tuneable params in `config.yaml` — no code changes needed |
| **Logging** | Coloured console + rotating `.log` + structured `.jsonl` |
| **Performance** | Frame-skip (YOLO every N frames) + inference-resolution downscale |

---

## Project structure

```
smart_object_detection/
├── app.py              # Streamlit web dashboard
├── main.py             # Core detection + alert engine
├── tracker.py          # DeepSORT wrapper
├── utils.py            # Drawing, geometry, alarm, screenshot helpers
├── config_loader.py    # YAML config loader with safe defaults
├── config.yaml         # ← Edit this to tune the system
├── logger_setup.py     # Structured logging (console + file + JSON)
├── generate_alarm.py   # Utility to regenerate the alarm WAV
├── requirements.txt
├── assets/
│   └── alarm.wav
├── screenshots/        # Auto-created on first run
└── logs/               # Auto-created on first run
    ├── detection_YYYYMMDD.log      # human-readable
    └── detection_YYYYMMDD.jsonl   # machine-readable (one JSON per line)
```

---

## Quick start

```bash
# 1. Clone
git clone https://github.com/your-username/smart-unattended-detection.git
cd smart-unattended-detection

# 2. Install dependencies
pip install -r requirements.txt

# 3. (Optional) edit config
nano config.yaml

# 4. Run the dashboard
streamlit run app.py

# — or — run headless on a video file
python main.py --source demo/airport.mp4 --no-display
```

> **First run**: YOLOv8 weights (~6 MB for `yolov8n.pt`) are downloaded automatically from Ultralytics.

---

## Configuration (`config.yaml`)

```yaml
model:
  path: "yolov8n.pt"        # swap for yolov8s/m/l for better accuracy
  confidence_threshold: 0.45

alerts:
  warning_time: 5           # seconds before WARNING
  critical_time: 10         # seconds before CRITICAL

performance:
  process_every_n_frames: 2 # skip frames to reduce CPU load
```

All parameters are documented inline in `config.yaml`.
Changes take effect immediately — no code edits required.

---

## Logging

Three outputs are written simultaneously:

| Output | Format | Location |
|---|---|---|
| Console | Coloured, human-readable | Terminal |
| Text file | Timestamped log lines | `logs/detection_YYYYMMDD.log` |
| JSON file | One JSON object per line | `logs/detection_YYYYMMDD.jsonl` |

Log files rotate automatically at 5 MB, keeping the last 3 files.

```bash
# Tail the live log
tail -f logs/detection_$(date +%Y%m%d).log

# Parse JSON log with jq
cat logs/detection_$(date +%Y%m%d).jsonl | jq 'select(.level == "WARNING")'
```

---

## Performance

| Setting | Effect |
|---|---|
| `process_every_n_frames: 2` | YOLO runs every 2nd frame — ~2× faster on CPU |
| `model.path: yolov8n.pt` | Fastest model — good for real-time on CPU |
| `model.path: yolov8s.pt` | Slightly slower, noticeably better accuracy |
| `model.device: cuda` | GPU inference if CUDA is available |

Typical throughput on a modern laptop CPU:
- `yolov8n` + frame-skip 2 → **~15–20 FPS** at 960 px
- `yolov8n` + frame-skip 1 → **~8–12 FPS** at 960 px

---

## Tech stack

- [Ultralytics YOLOv8](https://github.com/ultralytics/ultralytics)
- [deep-sort-realtime](https://github.com/levan92/deep_sort_realtime)
- [Streamlit](https://streamlit.io)
- [OpenCV](https://opencv.org)
- [PyYAML](https://pyyaml.org)
- [pygame](https://pygame.org)

---

## AI & Prompt Engineering — Final Project

Built as the final project for the *AI & Prompt Engineering* course.

**What makes it non-trivial:**
- Multi-model pipeline (YOLO + DeepSORT) working in real time
- Stateful owner-object relationship tracking across frames
- Production-quality code: config file, structured logging, performance optimisation
- Fully interactive Streamlit dashboard

---

*MIT License*

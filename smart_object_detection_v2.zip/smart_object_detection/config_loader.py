"""
Smart Unattended Object Detection System — config_loader.py
============================================================
Loads ``config.yaml`` (or any YAML config file) into a flat dict that is
compatible with the existing ``CONFIG`` dict used throughout the project.

Usage
-----
    from config_loader import load_config

    cfg = load_config()                      # loads config.yaml next to this file
    cfg = load_config("path/to/my.yaml")     # explicit path

The returned dict is the same shape as the hard-coded ``CONFIG`` in main.py,
so it can be dropped in as a direct replacement:

    detector = UnattendedObjectDetector(cfg=load_config())
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Default location: config.yaml sitting beside this file
_DEFAULT_CONFIG_PATH = Path(__file__).parent / "config.yaml"


def load_config(path: str | Path = _DEFAULT_CONFIG_PATH) -> dict[str, Any]:
    """
    Load YAML config and return a flat dict matching the CONFIG schema.

    Falls back to safe built-in defaults if the file is missing or malformed,
    so the system always starts even without a config file.

    Args:
        path: Path to a YAML config file.

    Returns:
        Flat configuration dict compatible with ``UnattendedObjectDetector``.
    """
    try:
        import yaml  # PyYAML — already pulled in by many ML stacks
    except ImportError:
        logger.warning("PyYAML not installed. Using built-in defaults. "
                       "Run: pip install pyyaml")
        return _defaults()

    path = Path(path)
    if not path.exists():
        logger.warning(f"Config file not found: {path}. Using built-in defaults.")
        return _defaults()

    try:
        with open(path, "r", encoding="utf-8") as fh:
            raw: dict = yaml.safe_load(fh) or {}
    except Exception as exc:
        logger.error(f"Failed to parse config file ({path}): {exc}. "
                     "Using built-in defaults.")
        return _defaults()

    cfg = _defaults()

    # ── model ──────────────────────────────────────────────────────────────
    m = raw.get("model", {})
    cfg["model_path"]            = m.get("path", cfg["model_path"])
    cfg["confidence_threshold"]  = float(m.get("confidence_threshold",
                                               cfg["confidence_threshold"]))
    if "device" in m:
        cfg["device"] = m["device"]

    # ── classes ────────────────────────────────────────────────────────────
    c = raw.get("classes", {})
    cfg["person_class_id"] = int(c.get("person_class_id", cfg["person_class_id"]))
    if "bag_class_ids" in c:
        cfg["bag_class_ids"] = set(int(x) for x in c["bag_class_ids"])

    # ── tracking ───────────────────────────────────────────────────────────
    t = raw.get("tracking", {})
    cfg["owner_link_distance"]   = int(t.get("owner_link_distance",
                                             cfg["owner_link_distance"]))
    cfg["owner_away_distance"]   = int(t.get("owner_away_distance",
                                             cfg["owner_away_distance"]))
    cfg["tracker_max_age"]       = int(t.get("max_age",        30))
    cfg["tracker_n_init"]        = int(t.get("n_init",          2))
    cfg["tracker_cosine_dist"]   = float(t.get("max_cosine_distance", 0.4))
    cfg["tracker_embedder"]      = t.get("embedder", "mobilenet")

    # ── alerts ─────────────────────────────────────────────────────────────
    a = raw.get("alerts", {})
    cfg["warning_time"]          = float(a.get("warning_time",  cfg["warning_time"]))
    cfg["critical_time"]         = float(a.get("critical_time", cfg["critical_time"]))
    cfg["warning_volume"]        = float(a.get("warning_volume",  0.5))
    cfg["critical_volume"]       = float(a.get("critical_volume", 1.0))

    # ── performance ────────────────────────────────────────────────────────
    p = raw.get("performance", {})
    cfg["process_every_n_frames"] = int(p.get("process_every_n_frames",
                                              cfg["process_every_n_frames"]))
    cfg["max_preview_width"]      = int(p.get("max_preview_width", 960))

    # ── output ─────────────────────────────────────────────────────────────
    o = raw.get("output", {})
    cfg["screenshot_dir"]   = o.get("screenshot_dir", cfg["screenshot_dir"])
    cfg["alarm_path"]       = o.get("alarm_path",     cfg["alarm_path"])
    cfg["log_dir"]          = o.get("log_dir",         "logs")
    cfg["log_level"]        = o.get("log_level",       "INFO").upper()
    cfg["log_to_file"]      = bool(o.get("log_to_file",     True))
    cfg["log_max_bytes"]    = int(o.get("log_max_bytes",    5 * 1024 * 1024))
    cfg["log_backup_count"] = int(o.get("log_backup_count", 3))

    # ── ui ─────────────────────────────────────────────────────────────────
    u = raw.get("ui", {})
    cfg["event_log_max"]      = int(u.get("event_log_max",     200))
    cfg["gallery_max_images"] = int(u.get("gallery_max_images", 12))

    _validate(cfg)
    logger.info(f"Config loaded from: {path}")
    return cfg


def _defaults() -> dict[str, Any]:
    """Return built-in default configuration (mirrors CONFIG in main.py)."""
    return {
        # model
        "model_path":             "yolov8n.pt",
        "confidence_threshold":   0.45,
        # classes
        "person_class_id":        0,
        "bag_class_ids":          {24, 26, 28},
        # tracking
        "owner_link_distance":    200,
        "owner_away_distance":    150,
        "tracker_max_age":        30,
        "tracker_n_init":         2,
        "tracker_cosine_dist":    0.4,
        "tracker_embedder":       "mobilenet",
        # alerts
        "warning_time":           5.0,
        "critical_time":          10.0,
        "warning_volume":         0.5,
        "critical_volume":        1.0,
        # performance
        "process_every_n_frames": 2,
        "max_preview_width":      960,
        # output
        "screenshot_dir":         "screenshots",
        "alarm_path":             "assets/alarm.wav",
        "log_dir":                "logs",
        "log_level":              "INFO",
        "log_to_file":            True,
        "log_max_bytes":          5 * 1024 * 1024,
        "log_backup_count":       3,
        # ui
        "event_log_max":          200,
        "gallery_max_images":     12,
    }


def _validate(cfg: dict[str, Any]) -> None:
    """Log warnings for suspicious configuration values."""
    if cfg["warning_time"] >= cfg["critical_time"]:
        logger.warning(
            f"warning_time ({cfg['warning_time']}s) should be less than "
            f"critical_time ({cfg['critical_time']}s)."
        )
    if not (0.0 < cfg["confidence_threshold"] < 1.0):
        logger.warning(
            f"confidence_threshold ({cfg['confidence_threshold']}) is outside "
            "the recommended range (0.0, 1.0)."
        )
    if cfg["owner_link_distance"] < cfg["owner_away_distance"]:
        logger.warning(
            "owner_link_distance is smaller than owner_away_distance — "
            "bags may never get an owner assigned."
        )

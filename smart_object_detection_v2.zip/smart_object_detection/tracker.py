"""
Smart Unattended Object Detection System — tracker.py
======================================================
Wraps the `deep_sort_realtime` library to provide a clean, unified
interface for multi-object tracking across video frames.

DeepSORT extends SORT (Simple Online and Realtime Tracking) with a
deep appearance descriptor so it can re-identify objects after occlusion.

Key concept:
    - YOLO gives us bounding boxes each frame (no memory between frames).
    - DeepSORT assigns a *persistent* integer ID to each object so we
      can track "has this specific backpack been unattended for 10 s?".
"""

import logging
from typing import Optional

import numpy as np
from deep_sort_realtime.deepsort_tracker import DeepSort

logger = logging.getLogger(__name__)

# COCO class IDs for objects we track
PERSON_CLASS_ID = 0
BAG_CLASS_IDS = {24, 26, 28}          # backpack, handbag, suitcase
TRACKED_CLASSES = BAG_CLASS_IDS | {PERSON_CLASS_ID}


class ObjectTracker:
    """
    Thin wrapper around DeepSort that:
      - Accepts raw YOLO detections
      - Returns a clean list of tracked objects with stable IDs
      - Preserves class_id across frames (DeepSORT strips it)
    """

    def __init__(
        self,
        max_age: int = 30,
        n_init: int = 2,
        max_cosine_distance: float = 0.4,
        nn_budget: Optional[int] = None,
        embedder: str = "mobilenet",
    ):
        """
        Args:
            max_age:              Frames to keep a track alive with no detection
            n_init:               Detections needed before a track is confirmed
            max_cosine_distance:  Appearance similarity threshold for re-ID
            nn_budget:            Cap on stored appearance vectors (None = unlimited)
            embedder:             CNN used for appearance features
                                  Options: 'mobilenet', 'torchreid', 'clip_RN50', etc.
        """
        self.tracker = DeepSort(
            max_age=max_age,
            n_init=n_init,
            max_cosine_distance=max_cosine_distance,
            nn_budget=nn_budget,
            embedder=embedder,
            half=False,        # Use full precision for stability
            bgr=True,          # Our frames are BGR (OpenCV default)
            embedder_gpu=False # Set True if CUDA is available
        )

        # Map track_id → class_id (DeepSORT doesn't return class after update)
        self._id_to_class: dict[int, int] = {}
        logger.info(
            f"DeepSORT tracker initialised "
            f"(max_age={max_age}, n_init={n_init}, embedder={embedder})"
        )

    def update(
        self,
        detections: list[dict],
        frame: np.ndarray,
    ) -> list[dict]:
        """
        Update tracker with new detections and return confirmed tracks.

        Args:
            detections: list of dicts from YOLO —
                        { 'bbox': [x1,y1,x2,y2], 'class_id': int, 'confidence': float }
            frame:      current BGR frame (needed for appearance embedding)

        Returns:
            list of dicts:
                { 'track_id': int, 'bbox': [x1,y1,x2,y2], 'class_id': int }
        """
        if not detections:
            # Still call update so DeepSORT can age-out stale tracks
            raw_tracks = self.tracker.update_tracks([], frame=frame)
            return []

        # ── Convert detections to DeepSORT input format ───────────────────
        # DeepSORT expects: ([left, top, width, height], confidence, class_label)
        ds_input = []
        for det in detections:
            x1, y1, x2, y2 = det["bbox"]
            w, h = x2 - x1, y2 - y1
            ds_input.append(
                ([x1, y1, w, h], det["confidence"], str(det["class_id"]))
            )

        # ── Run DeepSORT update ───────────────────────────────────────────
        raw_tracks = self.tracker.update_tracks(ds_input, frame=frame)

        # ── Parse confirmed tracks ────────────────────────────────────────
        results = []
        for track in raw_tracks:
            if not track.is_confirmed():
                continue  # Skip tentative tracks (n_init not reached yet)

            tid = int(track.track_id)
            ltrb = track.to_ltrb()                      # [left, top, right, bottom]
            bbox = [int(v) for v in ltrb]

            # Recover class_id from the detection that spawned / updated the track
            det_class = track.det_class                  # stored by deep_sort_realtime
            if det_class is not None:
                try:
                    cid = int(det_class)
                except (ValueError, TypeError):
                    cid = self._id_to_class.get(tid, -1)
            else:
                cid = self._id_to_class.get(tid, -1)

            # Persist so we can recover it in future frames
            if cid != -1:
                self._id_to_class[tid] = cid

            # Only return classes we care about
            if cid not in TRACKED_CLASSES:
                continue

            results.append({
                "track_id": tid,
                "bbox": bbox,
                "class_id": cid,
            })

        # Prune our class registry to avoid unbounded growth
        active_ids = {r["track_id"] for r in results}
        stale = [k for k in self._id_to_class if k not in active_ids]
        # Keep a small buffer for re-id; only prune if very stale
        if len(stale) > 200:
            for k in stale[:100]:
                del self._id_to_class[k]

        return results

    def reset(self):
        """Clear all tracks (call between video files, for example)."""
        self._id_to_class.clear()
        # Re-initialise DeepSort object
        self.tracker = DeepSort(
            max_age=30,
            n_init=2,
            max_cosine_distance=0.4,
            bgr=True,
            embedder="mobilenet",
            half=False,
            embedder_gpu=False,
        )
        logger.info("Tracker reset.")

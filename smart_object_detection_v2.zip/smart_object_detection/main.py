"""
Smart Unattended Object Detection System — main.py
====================================================
Core processing engine that handles:
  - YOLOv8 object detection
  - DeepSORT tracking
  - Owner-object relationship linking
  - Suspicious / alert logic with time thresholds
  - Screenshot capture & alarm triggering

Improvements over v1
--------------------
  * Loads settings from ``config.yaml`` via ``config_loader``
  * Structured logging via ``logger_setup`` (console + rotating file + JSON)
  * Frame-skip optimisation: YOLO only runs every N frames;
    DeepSORT-only update runs on skipped frames for smooth tracking
  * Inference-resolution downscale: YOLO runs on a smaller copy,
    boxes mapped back to original resolution for crisp rendering
  * Performance stats exposed via latest_stats dict

Author: AI & Prompt Engineering Final Project
"""

from __future__ import annotations

import argparse
import os
import time
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from ultralytics import YOLO

from config_loader import load_config
from logger_setup import setup_logging, get_logger
from tracker import ObjectTracker
from utils import (
    play_alarm,
    capture_screenshot,
    draw_detections,
    calculate_center,
    calculate_distance,
    draw_status_panel,
)

# Bootstrap logging with defaults before config is loaded
_raw_cfg = load_config()
setup_logging(_raw_cfg)
logger = get_logger(__name__)

CONFIG = _raw_cfg

CLASS_LABELS = {24: "backpack", 26: "handbag", 28: "suitcase", 0: "person"}

COLORS = {
    "safe":     (0, 200, 80),
    "warning":  (0, 165, 255),
    "critical": (0, 0, 220),
    "person":   (255, 200, 0),
}

_INFER_WIDTH = 640  # px — YOLO inference resolution (faster on CPU)


class ObjectState:
    """Runtime state for a single tracked bag / luggage object."""

    __slots__ = [
        "track_id", "class_id", "owner_id",
        "unattended_since", "last_seen_bbox",
        "alert_status", "screenshot_taken",
        "alarm_played", "first_seen",
    ]

    def __init__(self, track_id: int, class_id: int):
        self.track_id: int                     = track_id
        self.class_id: int                     = class_id
        self.owner_id: Optional[int]           = None
        self.unattended_since: Optional[float] = None
        self.last_seen_bbox                    = None
        self.alert_status: str                 = "safe"
        self.screenshot_taken: bool            = False
        self.alarm_played: bool                = False
        self.first_seen: float                 = time.time()


class UnattendedObjectDetector:
    """
    Orchestrates the full detection + tracking + alert pipeline.

    Usage::

        detector = UnattendedObjectDetector()
        detector.run(source=0)
        detector.run(source="video.mp4")
    """

    def __init__(self, cfg: dict = CONFIG):
        self.cfg = cfg
        setup_logging(cfg)
        self.model = self._load_model()
        self.tracker = ObjectTracker(
            max_age=cfg.get("tracker_max_age", 30),
            n_init=cfg.get("tracker_n_init", 2),
            max_cosine_distance=cfg.get("tracker_cosine_dist", 0.4),
            embedder=cfg.get("tracker_embedder", "mobilenet"),
        )
        self.object_states:    dict[int, ObjectState] = {}
        self.person_positions: dict[int, tuple]       = {}
        self.frame_count    = 0
        self.latest_stats   = {}
        self._last_raw_detections: list[dict] = []

        # Perf counters
        self._total_infer_ms = 0.0
        self._infer_frames   = 0

        Path(self.cfg["screenshot_dir"]).mkdir(parents=True, exist_ok=True)
        logger.info("UnattendedObjectDetector initialised")

    def _load_model(self) -> YOLO:
        logger.info(f"Loading YOLO model: {self.cfg['model_path']}")
        model = YOLO(self.cfg["model_path"])
        device = self.cfg.get("device")
        if device:
            model.to(device)
        logger.info(f"Model loaded (device={device or 'auto'})")
        return model

    def _scale_to_infer(self, frame: np.ndarray) -> tuple[np.ndarray, float]:
        """Downscale frame for YOLO, return (small_frame, scale_factor)."""
        h, w = frame.shape[:2]
        if w <= _INFER_WIDTH:
            return frame, 1.0
        scale = _INFER_WIDTH / w
        small = cv2.resize(frame, (int(w * scale), int(h * scale)),
                           interpolation=cv2.INTER_AREA)
        return small, scale

    def _detect(self, frame: np.ndarray) -> list[dict]:
        """Run YOLOv8 on a downscaled copy, map bboxes back to original size."""
        infer_frame, scale = self._scale_to_infer(frame)

        t0 = time.perf_counter()
        results = self.model(
            infer_frame,
            verbose=False,
            conf=self.cfg["confidence_threshold"],
        )[0]
        elapsed_ms = (time.perf_counter() - t0) * 1000
        self._total_infer_ms += elapsed_ms
        self._infer_frames   += 1
        logger.debug(f"YOLO inference: {elapsed_ms:.1f} ms "
                     f"(avg {self._total_infer_ms / self._infer_frames:.1f} ms)")

        detections = []
        for box in results.boxes:
            cls_id = int(box.cls[0])
            if (cls_id != self.cfg["person_class_id"]
                    and cls_id not in self.cfg["bag_class_ids"]):
                continue
            x1, y1, x2, y2 = (int(v / scale) for v in map(float, box.xyxy[0]))
            detections.append({
                "bbox":       [x1, y1, x2, y2],
                "class_id":   cls_id,
                "confidence": float(box.conf[0]),
            })
        return detections

    def _find_nearest_person(self, bag_center: tuple) -> Optional[int]:
        if not self.person_positions:
            return None
        best_id, best_dist = None, float("inf")
        for pid, pcenter in self.person_positions.items():
            dist = calculate_distance(bag_center, pcenter)
            if dist < best_dist:
                best_dist, best_id = dist, pid
        return best_id if best_dist <= self.cfg["owner_link_distance"] else None

    def _update_owner_distance(self, state: ObjectState) -> Optional[float]:
        if state.owner_id is None or state.last_seen_bbox is None:
            return None
        bag_center   = calculate_center(state.last_seen_bbox)
        owner_center = self.person_positions.get(state.owner_id)
        return calculate_distance(bag_center, owner_center) if owner_center else None

    def _evaluate_alert(self, state: ObjectState, dist: Optional[float]) -> str:
        owner_away = dist is None or dist > self.cfg["owner_away_distance"]

        if not owner_away:
            state.unattended_since = None
            state.alert_status     = "safe"
            state.screenshot_taken = False
            state.alarm_played     = False
            return "safe"

        now = time.time()
        if state.unattended_since is None:
            state.unattended_since = now
            logger.debug(f"Object #{state.track_id} timer started")

        elapsed = now - state.unattended_since
        if elapsed >= self.cfg["critical_time"]:
            return "critical"
        elif elapsed >= self.cfg["warning_time"]:
            return "warning"
        return "safe"

    def _handle_alerts(self, state: ObjectState, frame: np.ndarray):
        label = CLASS_LABELS.get(state.class_id, "object")

        if state.alert_status == "warning" and not state.alarm_played:
            logger.warning(
                f"[WARNING] {label.capitalize()} #{state.track_id} "
                f"unattended >= {self.cfg['warning_time']:.0f}s"
            )
            play_alarm(self.cfg["alarm_path"],
                       volume=self.cfg.get("warning_volume", 0.5))
            state.alarm_played = True

        if state.alert_status == "critical" and not state.screenshot_taken:
            elapsed = (time.time() - state.unattended_since
                       if state.unattended_since else 0)
            logger.error(
                f"[CRITICAL] {label.capitalize()} #{state.track_id} "
                f"unattended {elapsed:.0f}s — capturing screenshot"
            )
            play_alarm(self.cfg["alarm_path"],
                       volume=self.cfg.get("critical_volume", 1.0))
            ts   = time.strftime("%Y%m%d_%H%M%S")
            path = os.path.join(
                self.cfg["screenshot_dir"],
                f"alert_{state.track_id}_{ts}.jpg",
            )
            capture_screenshot(frame, path)
            state.screenshot_taken = True

    def process_frame(self, frame: np.ndarray) -> tuple[np.ndarray, dict]:
        """
        Process a single video frame end-to-end.

        YOLO only runs every ``process_every_n_frames`` frames.
        DeepSORT still updates every frame for smooth track positions.

        Returns (annotated_frame, stats_dict).
        """
        self.frame_count += 1
        skip = self.cfg.get("process_every_n_frames", 2)

        # 1. Detection (keyframes only)
        if self.frame_count % skip == 0:
            self._last_raw_detections = self._detect(frame)

        # 2. Tracking (every frame)
        tracked_objects = self.tracker.update(self._last_raw_detections, frame)

        # 3. Classify tracked objects
        self.person_positions = {}
        current_bag_ids: set[int] = set()

        for obj in tracked_objects:
            tid, cid, bbox = obj["track_id"], obj["class_id"], obj["bbox"]
            if cid == self.cfg["person_class_id"]:
                self.person_positions[tid] = calculate_center(bbox)
            elif cid in self.cfg["bag_class_ids"]:
                current_bag_ids.add(tid)
                if tid not in self.object_states:
                    self.object_states[tid] = ObjectState(tid, cid)
                    logger.info(
                        f"New {CLASS_LABELS.get(cid, 'object')} — ID #{tid}"
                    )
                self.object_states[tid].last_seen_bbox = bbox

        # 4. Remove stale states
        for gid in set(self.object_states) - current_bag_ids:
            logger.debug(f"Object #{gid} left frame")
            del self.object_states[gid]

        # 5. Owner linking + alert evaluation
        alert_counts = {"safe": 0, "warning": 0, "critical": 0}
        for tid, state in self.object_states.items():
            bag_center = calculate_center(state.last_seen_bbox)
            if state.owner_id is None or state.owner_id not in self.person_positions:
                state.owner_id = self._find_nearest_person(bag_center)
            dist = self._update_owner_distance(state)
            state.alert_status = self._evaluate_alert(state, dist)
            self._handle_alerts(state, frame)
            alert_counts[state.alert_status] += 1

        # 6. Draw annotations
        annotated = draw_detections(
            frame.copy(), tracked_objects, self.object_states,
            self.person_positions, COLORS, CLASS_LABELS,
        )
        annotated = draw_status_panel(annotated, alert_counts, self.frame_count)

        # 7. Stats for UI
        stats = {
            "frame":          self.frame_count,
            "persons":        len(self.person_positions),
            "bags":           len(self.object_states),
            "warnings":       alert_counts["warning"],
            "criticals":      alert_counts["critical"],
            "avg_infer_ms":   (
                round(self._total_infer_ms / self._infer_frames, 1)
                if self._infer_frames else 0.0
            ),
            "objects": [
                {
                    "id":               s.track_id,
                    "label":            CLASS_LABELS.get(s.class_id, "object"),
                    "status":           s.alert_status,
                    "owner_id":         s.owner_id,
                    "unattended_since": s.unattended_since,
                    "first_seen":       s.first_seen,
                }
                for s in self.object_states.values()
            ],
        }
        self.latest_stats = stats
        return annotated, stats

    def run(self, source=0, display: bool = True):
        """Main loop over a video source."""
        cap = cv2.VideoCapture(source)
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open video source: {source}")

        fps = cap.get(cv2.CAP_PROP_FPS) or 0
        w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        logger.info(f"Source: {source}  ({w}x{h} @ {fps:.1f} fps)")
        logger.info("Controls: [q] quit  [s] screenshot")

        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    logger.info("End of stream.")
                    break

                annotated, stats = self.process_frame(frame)

                if display:
                    cv2.imshow("Smart Unattended Object Detection", annotated)
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord("q"):
                        break
                    elif key == ord("s"):
                        ts = time.strftime("%Y%m%d_%H%M%S")
                        capture_screenshot(frame, f"screenshots/manual_{ts}.jpg")
                        logger.info("Manual screenshot saved.")
        finally:
            cap.release()
            if display:
                cv2.destroyAllWindows()
            avg = (self._total_infer_ms / self._infer_frames
                   if self._infer_frames else 0)
            logger.info(
                f"Done. frames={self.frame_count}  "
                f"avg_yolo={avg:.1f}ms"
            )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Smart Unattended Object Detection")
    parser.add_argument("--source", default=0,
                        help="0=webcam or path to video file")
    parser.add_argument("--config", default="config.yaml",
                        help="Path to YAML config (default: config.yaml)")
    parser.add_argument("--no-display", action="store_true",
                        help="Headless / no OpenCV window")
    args = parser.parse_args()

    cfg    = load_config(args.config)
    setup_logging(cfg)
    source = int(args.source) if str(args.source).isdigit() else args.source

    detector = UnattendedObjectDetector(cfg=cfg)
    detector.run(source=source, display=not args.no_display)

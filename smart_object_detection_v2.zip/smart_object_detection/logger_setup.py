"""
Smart Unattended Object Detection System — logger_setup.py
===========================================================
Centralised logging setup for the whole project.

Features
--------
* Console handler  — coloured, human-readable output
* Rotating file handler  — writes to ``logs/detection_YYYYMMDD.log``
  with automatic rotation (size-based) so the disk never fills up
* Structured JSON handler (optional)  — machine-readable lines for
  downstream parsing / dashboards
* Single call-site: ``setup_logging(cfg)`` wires everything up once;
  every ``logging.getLogger(__name__)`` call in the project picks it up
  automatically.

Usage
-----
    from logger_setup import setup_logging
    from config_loader import load_config

    cfg = load_config()
    setup_logging(cfg)                 # call once at startup

    import logging
    logger = logging.getLogger(__name__)
    logger.info("System started")
    logger.warning("Bag #3 unattended for 6s")
    logger.error("Cannot open video source")
"""

from __future__ import annotations

import json
import logging
import logging.handlers
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Any


# ─── ANSI colour codes for terminal output ───────────────────────────────────

_RESET  = "\033[0m"
_BOLD   = "\033[1m"
_GREY   = "\033[38;5;245m"
_CYAN   = "\033[36m"
_GREEN  = "\033[32m"
_YELLOW = "\033[33m"
_RED    = "\033[31m"
_BRED   = "\033[1;31m"

_LEVEL_COLORS = {
    "DEBUG":    _GREY,
    "INFO":     _GREEN,
    "WARNING":  _YELLOW,
    "ERROR":    _RED,
    "CRITICAL": _BRED,
}


class _ColorFormatter(logging.Formatter):
    """Console formatter with ANSI colours and compact timestamps."""

    FMT = "{color}{levelname:<8}{reset} {grey}{asctime}{reset}  {msg}"

    def format(self, record: logging.LogRecord) -> str:  # noqa: A003
        color = _LEVEL_COLORS.get(record.levelname, _RESET)
        ts    = datetime.fromtimestamp(record.created).strftime("%H:%M:%S.%f")[:-3]
        msg   = record.getMessage()
        if record.exc_info:
            msg += "\n" + self.formatException(record.exc_info)
        return self.FMT.format(
            color=color, levelname=record.levelname, reset=_RESET,
            grey=_GREY, asctime=ts, msg=msg,
        )


class _JSONFormatter(logging.Formatter):
    """
    Emit one JSON object per line — useful for log aggregators (ELK, Loki, etc.).

    Example line::

        {"ts": 1714300512.345, "level": "WARNING", "logger": "main",
         "msg": "Bag #3 unattended for 6s", "module": "main", "line": 182}
    """

    def format(self, record: logging.LogRecord) -> str:  # noqa: A003
        payload: dict[str, Any] = {
            "ts":     round(record.created, 3),
            "iso":    datetime.fromtimestamp(record.created).isoformat(timespec="milliseconds"),
            "level":  record.levelname,
            "logger": record.name,
            "module": record.module,
            "line":   record.lineno,
            "msg":    record.getMessage(),
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


# ─── Public API ───────────────────────────────────────────────────────────────

def setup_logging(cfg: dict[str, Any] | None = None) -> None:
    """
    Configure the root logger once for the entire application.

    Call this **once** at the top of your entry point (``main.py``, ``app.py``).
    Subsequent ``logging.getLogger(...)`` calls throughout the codebase will
    automatically inherit this configuration.

    Args:
        cfg: Configuration dict (from ``config_loader.load_config()``).
             If *None*, safe defaults are used so the function never raises.
    """
    if cfg is None:
        cfg = {}

    level_name  = cfg.get("log_level", "INFO").upper()
    level       = getattr(logging, level_name, logging.INFO)
    log_to_file = cfg.get("log_to_file", True)
    log_dir     = Path(cfg.get("log_dir", "logs"))
    max_bytes   = int(cfg.get("log_max_bytes",    5 * 1024 * 1024))
    backup_cnt  = int(cfg.get("log_backup_count", 3))

    root = logging.getLogger()
    root.setLevel(level)

    # Remove any handlers added by earlier basicConfig calls
    root.handlers.clear()

    # ── Console handler ───────────────────────────────────────────────────
    console = logging.StreamHandler()
    console.setLevel(level)
    console.setFormatter(_ColorFormatter())
    root.addHandler(console)

    # ── Rotating file handlers ────────────────────────────────────────────
    if log_to_file:
        log_dir.mkdir(parents=True, exist_ok=True)
        date_str  = datetime.now().strftime("%Y%m%d")

        # Human-readable log
        txt_path = log_dir / f"detection_{date_str}.log"
        txt_handler = logging.handlers.RotatingFileHandler(
            txt_path, maxBytes=max_bytes, backupCount=backup_cnt, encoding="utf-8"
        )
        txt_handler.setLevel(level)
        txt_handler.setFormatter(
            logging.Formatter(
                fmt="%(asctime)s [%(levelname)-8s] %(name)s — %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        root.addHandler(txt_handler)

        # Machine-readable JSON log (always at DEBUG level for full detail)
        json_path = log_dir / f"detection_{date_str}.jsonl"
        json_handler = logging.handlers.RotatingFileHandler(
            json_path, maxBytes=max_bytes, backupCount=backup_cnt, encoding="utf-8"
        )
        json_handler.setLevel(logging.DEBUG)
        json_handler.setFormatter(_JSONFormatter())
        root.addHandler(json_handler)

        logging.getLogger(__name__).info(
            f"Logging to: {txt_path}  |  JSON: {json_path}"
        )

    # Suppress noisy third-party loggers
    for noisy in ("ultralytics", "deep_sort_realtime", "PIL", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    logging.getLogger(__name__).info(
        f"Logging configured — level={level_name}, file={log_to_file}"
    )


def get_logger(name: str) -> logging.Logger:
    """
    Convenience wrapper — identical to ``logging.getLogger(name)`` but
    documents intent clearly.

    Usage::

        from logger_setup import get_logger
        logger = get_logger(__name__)
    """
    return logging.getLogger(name)

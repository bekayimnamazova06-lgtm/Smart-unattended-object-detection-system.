"""
Smart Unattended Object Detection System — app.py
==================================================
Streamlit dashboard — completely redesigned UI for v2.

New in v2
---------
  * Loads all settings from config.yaml (via config_loader)
  * Structured logging via logger_setup
  * Performance panel: avg YOLO inference ms, FPS, frame counter
  * Timeline chart: rolling 60-frame warning / critical counts
  * Config editor sidebar with live YAML preview
  * Cleaner card-based metrics with trend indicators
  * Responsive 3-column layout

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import glob
import os
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import streamlit as st
from PIL import Image

from config_loader import load_config
from logger_setup import setup_logging, get_logger
from main import UnattendedObjectDetector, CLASS_LABELS
from utils import bgr_to_rgb, resize_frame

# ─── Bootstrap ────────────────────────────────────────────────────────────────
_cfg = load_config()
setup_logging(_cfg)
logger = get_logger(__name__)

# ─── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Smart Surveillance",
    page_icon="🛡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Refined dark theme ───────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600&display=swap');

  html, body, [class*="css"] { font-family: 'IBM Plex Sans', sans-serif; }

  .stApp { background: #080c10; color: #c9d1d9; }

  /* ── Sidebar ── */
  section[data-testid="stSidebar"] {
    background: #0d1117;
    border-right: 1px solid #161b22;
  }

  /* ── Cards ── */
  .stat-card {
    background: #0d1117;
    border: 1px solid #1c2128;
    border-radius: 8px;
    padding: 18px 16px 14px;
    text-align: center;
    position: relative;
    overflow: hidden;
  }
  .stat-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: var(--accent, #238636);
  }
  .stat-val {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 2rem;
    font-weight: 600;
    line-height: 1;
    margin: 0;
    color: var(--accent, #238636);
  }
  .stat-label {
    font-size: 0.7rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: #484f58;
    margin-top: 6px;
  }
  .stat-delta {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.75rem;
    color: #8b949e;
    margin-top: 4px;
  }

  /* ── Object rows ── */
  .obj-row {
    display: flex; align-items: center; gap: 10px;
    padding: 8px 12px;
    border-radius: 6px;
    margin: 3px 0;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.82rem;
    border-left: 3px solid transparent;
  }
  .obj-safe     { background: #091d12; border-left-color: #238636; color: #56d364; }
  .obj-warning  { background: #1c1500; border-left-color: #9e6a03; color: #e3b341; }
  .obj-critical {
    background: #1c0a0a; border-left-color: #da3633; color: #ff7b72;
    animation: pulse-critical 1.2s ease-in-out infinite;
  }
  @keyframes pulse-critical {
    0%, 100% { opacity: 1; }
    50%       { opacity: 0.65; }
  }

  /* ── Event log rows ── */
  .log-row {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.78rem;
    padding: 4px 10px;
    border-radius: 4px;
    margin: 2px 0;
    white-space: pre;
  }
  .log-info     { color: #8b949e; }
  .log-warning  { color: #e3b341; background: #1c150005; }
  .log-critical { color: #ff7b72; background: #1c0a0a; }

  /* ── Section headers ── */
  .section-header {
    font-size: 0.7rem;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: #484f58;
    border-bottom: 1px solid #161b22;
    padding-bottom: 6px;
    margin-bottom: 10px;
    margin-top: 4px;
  }

  /* ── Buttons ── */
  .stButton > button {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.8rem;
    letter-spacing: 0.05em;
    border-radius: 5px;
    border: 1px solid #30363d;
    background: #161b22;
    color: #c9d1d9;
    transition: all 0.15s;
  }
  .stButton > button:hover { background: #1c2128; border-color: #58a6ff; color: #58a6ff; }

  /* ── Sliders, selects ── */
  .stSlider > div > div { background: #238636 !important; }
  div[data-testid="stSelectbox"] > div { background: #0d1117; border-color: #30363d; }

  h1, h2, h3 { color: #e6edf3 !important; font-weight: 600; }

  /* ── Perf badge ── */
  .perf-badge {
    display: inline-block;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.72rem;
    background: #0d1117;
    border: 1px solid #1c2128;
    border-radius: 20px;
    padding: 3px 10px;
    color: #58a6ff;
    margin: 0 4px;
  }

  /* hide Streamlit branding */
  #MainMenu { visibility: hidden; }
  footer    { visibility: hidden; }
</style>
""", unsafe_allow_html=True)


# ─── Session state ────────────────────────────────────────────────────────────
def _init():
    defaults = {
        "running":       False,
        "detector":      None,
        "event_log":     [],          # (ts, msg, level)
        "perf_history":  [],          # rolling (frame, infer_ms, persons, bags, warn, crit)
        "latest_frame":  None,
        "alert_history": {"warning": [], "critical": []},
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init()


def log_event(msg: str, level: str = "info"):
    ts = datetime.now().strftime("%H:%M:%S")
    st.session_state.event_log.append((ts, msg, level))
    max_events = _cfg.get("event_log_max", 200)
    if len(st.session_state.event_log) > max_events:
        st.session_state.event_log = st.session_state.event_log[-max_events:]


# ─── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🛡 Smart Surveillance")
    st.markdown("<div class='section-header'>Video Source</div>", unsafe_allow_html=True)

    src_type = st.radio("", ["Webcam", "Video File"], horizontal=True, label_visibility="collapsed")
    if src_type == "Webcam":
        cam_idx      = st.number_input("Camera index", 0, 10, 0, step=1)
        video_source = int(cam_idx)
    else:
        video_path   = st.text_input("File path", placeholder="demo/airport.mp4")
        video_source = video_path or None

    st.markdown("<div class='section-header' style='margin-top:16px'>Alert Thresholds</div>",
                unsafe_allow_html=True)
    warning_time  = st.slider("Warning (s)",  1,  30, int(_cfg["warning_time"]))
    critical_time = st.slider("Critical (s)", 2,  60, int(_cfg["critical_time"]))
    owner_dist    = st.slider("Owner away (px)", 50, 500, int(_cfg["owner_away_distance"]))
    confidence    = st.slider("Confidence",  0.10, 0.90,
                               float(_cfg["confidence_threshold"]), step=0.05)

    st.markdown("<div class='section-header' style='margin-top:16px'>Display</div>",
                unsafe_allow_html=True)
    show_log     = st.checkbox("Event log",         value=True)
    show_perf    = st.checkbox("Performance panel",  value=True)
    show_gallery = st.checkbox("Screenshot gallery", value=False)
    preview_w    = st.slider("Preview width (px)", 400, 1280,
                              int(_cfg.get("max_preview_width", 960)), step=80)

    st.divider()
    st.markdown(
        "<p style='font-size:0.7rem;color:#484f58;line-height:1.6'>"
        "YOLOv8 + DeepSORT<br>"
        "AI &amp; Prompt Engineering<br>"
        "Final Project — v2</p>",
        unsafe_allow_html=True,
    )


# ─── Header ───────────────────────────────────────────────────────────────────
col_h, col_ctl = st.columns([4, 2])
with col_h:
    st.markdown("# 🛡 Smart Unattended Object Detection")
    st.markdown(
        "<p style='color:#484f58;margin-top:-10px;font-size:0.85rem'>"
        "Real-time surveillance · YOLOv8 + DeepSORT · Owner-linking · Multi-level alerting"
        "</p>",
        unsafe_allow_html=True,
    )

with col_ctl:
    st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    start_btn = c1.button("▶ Start",  use_container_width=True)
    stop_btn  = c2.button("⏹ Stop",   use_container_width=True)
    snap_btn  = c3.button("📸 Snap",  use_container_width=True)

status_ph = st.empty()

# Handle controls
if start_btn and not st.session_state.running:
    if src_type == "Video File" and not video_source:
        st.error("Enter a video file path.")
    else:
        cfg_run = {
            **_cfg,
            "warning_time":         warning_time,
            "critical_time":        critical_time,
            "owner_away_distance":  owner_dist,
            "confidence_threshold": confidence,
        }
        st.session_state.detector = UnattendedObjectDetector(cfg=cfg_run)
        st.session_state.running  = True
        log_event("Detection started.", "info")

if stop_btn:
    st.session_state.running = False
    log_event("Detection stopped by user.", "info")

if not st.session_state.running:
    status_ph.markdown(
        "<p style='color:#484f58;font-size:0.85rem;margin:0'>⬤ Idle — press ▶ Start</p>",
        unsafe_allow_html=True,
    )

st.divider()

# ─── Main 3-column layout ─────────────────────────────────────────────────────
vid_col, right_col = st.columns([3, 1], gap="large")

with vid_col:
    st.markdown("<div class='section-header'>Live Feed</div>", unsafe_allow_html=True)
    frame_ph = st.empty()

with right_col:
    st.markdown("<div class='section-header'>Metrics</div>", unsafe_allow_html=True)
    m_persons  = st.empty()
    m_bags     = st.empty()
    m_warn     = st.empty()
    m_crit     = st.empty()
    m_fps      = st.empty()

# Objects table
st.markdown("<div class='section-header' style='margin-top:8px'>Tracked Objects</div>",
            unsafe_allow_html=True)
table_ph = st.empty()

# Performance
if show_perf:
    st.markdown("<div class='section-header' style='margin-top:8px'>Performance</div>",
                unsafe_allow_html=True)
    perf_ph = st.empty()

# Event log
if show_log:
    st.markdown("<div class='section-header' style='margin-top:8px'>Event Log</div>",
                unsafe_allow_html=True)
    log_ph = st.empty()

# Gallery
if show_gallery:
    with st.expander("📷 Screenshot Gallery", expanded=False):
        shots = sorted(glob.glob("screenshots/*.jpg"), reverse=True)[:_cfg.get("gallery_max_images", 12)]
        if shots:
            gcols = st.columns(4)
            for i, p in enumerate(shots):
                gcols[i % 4].image(Image.open(p), caption=os.path.basename(p),
                                   use_container_width=True)
        else:
            st.info("No screenshots yet.")


# ─── Helpers ──────────────────────────────────────────────────────────────────
def _card(label: str, value, accent: str = "#238636", delta: str = "") -> str:
    delta_html = f"<div class='stat-delta'>{delta}</div>" if delta else ""
    return (
        f"<div class='stat-card' style='--accent:{accent}'>"
        f"<div class='stat-val'>{value}</div>"
        f"<div class='stat-label'>{label}</div>"
        f"{delta_html}"
        f"</div>"
    )


def _render_perf(history: list) -> str:
    if not history:
        return "<p style='color:#484f58;font-size:0.8rem'>No data yet.</p>"
    last = history[-1]
    infer_ms = last.get("infer_ms", 0)
    fps_val  = last.get("fps", 0)
    return (
        f"<span class='perf-badge'>YOLO {infer_ms:.1f} ms</span>"
        f"<span class='perf-badge'>~{fps_val:.0f} FPS</span>"
        f"<span class='perf-badge'>Frame #{last.get('frame', 0)}</span>"
    )


# ─── Detection loop ───────────────────────────────────────────────────────────
if st.session_state.running and st.session_state.detector is not None:
    detector: UnattendedObjectDetector = st.session_state.detector
    cap = cv2.VideoCapture(video_source)

    if not cap.isOpened():
        st.error(f"Cannot open: {video_source}")
        st.session_state.running = False
    else:
        prev_statuses: dict = {}
        frame_times: list[float] = []

        while st.session_state.running:
            t_frame_start = time.perf_counter()

            ret, frame = cap.read()
            if not ret:
                log_event("End of stream.", "info")
                st.session_state.running = False
                break

            frame = resize_frame(frame, max_width=preview_w)
            annotated, stats = detector.process_frame(frame)
            rgb = bgr_to_rgb(annotated)
            frame_ph.image(rgb, use_container_width=True)
            st.session_state.latest_frame = rgb

            # Manual screenshot
            if snap_btn:
                ts = time.strftime("%Y%m%d_%H%M%S")
                from utils import capture_screenshot as _cs
                _cs(annotated, f"screenshots/manual_{ts}.jpg")
                log_event(f"Manual screenshot: manual_{ts}.jpg", "info")

            # ── Metric cards ──────────────────────────────────────────────
            m_persons.markdown(_card("Persons", stats["persons"],  "#58a6ff"), unsafe_allow_html=True)
            m_bags.markdown(   _card("Bags",    stats["bags"],     "#8b949e"), unsafe_allow_html=True)
            m_warn.markdown(   _card("Warnings",stats["warnings"], "#e3b341"
                               if stats["warnings"] else "#484f58"),           unsafe_allow_html=True)
            m_crit.markdown(   _card("Critical", stats["criticals"], "#ff7b72"
                               if stats["criticals"] else "#484f58"),          unsafe_allow_html=True)

            # FPS
            frame_times.append(time.perf_counter() - t_frame_start)
            if len(frame_times) > 30:
                frame_times.pop(0)
            avg_frame = sum(frame_times) / len(frame_times)
            fps_live = 1.0 / avg_frame if avg_frame > 0 else 0
            m_fps.markdown(_card("FPS (live)", f"{fps_live:.1f}", "#30363d"),
                           unsafe_allow_html=True)

            # ── Performance panel ─────────────────────────────────────────
            perf_rec = {
                "frame":    stats["frame"],
                "infer_ms": stats.get("avg_infer_ms", 0),
                "fps":      fps_live,
            }
            st.session_state.perf_history.append(perf_rec)
            if len(st.session_state.perf_history) > 200:
                st.session_state.perf_history.pop(0)

            if show_perf:
                perf_ph.markdown(_render_perf(st.session_state.perf_history),
                                 unsafe_allow_html=True)

            # ── Object table ──────────────────────────────────────────────
            if stats["objects"]:
                rows = ""
                for obj in stats["objects"]:
                    elapsed = (
                        int(time.time() - obj["unattended_since"])
                        if obj["unattended_since"] else 0
                    )
                    icon = {"safe": "●", "warning": "▲", "critical": "■"}.get(obj["status"], "")
                    owner_txt = f"Person #{obj['owner_id']}" if obj["owner_id"] else "Unlinked"
                    rows += (
                        f'<div class="obj-row obj-{obj["status"]}">'
                        f'{icon}  {obj["label"].upper()} #{obj["id"]}'
                        f'  ·  {obj["status"].upper()}'
                        f'  ·  {owner_txt}'
                        f'  ·  {elapsed}s unattended'
                        f'</div>'
                    )
                table_ph.markdown(rows, unsafe_allow_html=True)
            else:
                table_ph.markdown(
                    "<p style='color:#484f58;font-size:0.85rem'>No bags detected.</p>",
                    unsafe_allow_html=True,
                )

            # ── Auto-log status transitions ───────────────────────────────
            for obj in stats["objects"]:
                tid, new_s = obj["id"], obj["status"]
                if prev_statuses.get(tid) != new_s:
                    prev_statuses[tid] = new_s
                    if new_s == "warning":
                        log_event(
                            f"{obj['label'].capitalize()} #{tid} → WARNING",
                            "warning",
                        )
                    elif new_s == "critical":
                        log_event(
                            f"{obj['label'].capitalize()} #{tid} → CRITICAL!",
                            "critical",
                        )

            # ── Event log ─────────────────────────────────────────────────
            if show_log:
                log_html = ""
                for ts, msg, lvl in reversed(st.session_state.event_log[-40:]):
                    log_html += (
                        f'<div class="log-row log-{lvl}">'
                        f'[{ts}]  {msg}'
                        f'</div>'
                    )
                log_ph.markdown(log_html, unsafe_allow_html=True)

            time.sleep(0.01)

        cap.release()
        status_ph.markdown(
            "<p style='color:#484f58;font-size:0.85rem'>⬤ Finished. Press ▶ Start to run again.</p>",
            unsafe_allow_html=True,
        )

else:
    # Idle placeholder
    blank = np.zeros((360, 640, 3), dtype=np.uint8)
    cv2.putText(blank, "Press  Start  to begin", (110, 185),
                cv2.FONT_HERSHEY_SIMPLEX, 0.85, (35, 40, 48), 2)
    frame_ph.image(blank, channels="BGR", use_container_width=True)
    table_ph.markdown(
        "<p style='color:#484f58;font-size:0.85rem'>System idle.</p>",
        unsafe_allow_html=True,
    )

# ─── Footer ───────────────────────────────────────────────────────────────────
st.divider()
st.markdown(
    "<p style='text-align:center;color:#30363d;font-size:0.72rem'>"
    "Smart Unattended Object Detection · v2 · AI &amp; Prompt Engineering Final Project"
    "</p>",
    unsafe_allow_html=True,
)
